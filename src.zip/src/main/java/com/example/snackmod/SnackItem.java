package com.example.snackmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;

public class SnackItem extends Item {
    private final boolean drink;
    private final int ticks;

    public SnackItem(Properties props, boolean drink, int ticks) {
        super(props);
        this.drink = drink;
        this.ticks = ticks;
    }

    @Override public UseAnim getUseAnimation(ItemStack s) { return drink ? UseAnim.DRINK : UseAnim.EAT; }
    @Override public int getUseDuration(ItemStack s) { return ticks; }
    @Override public SoundEvent getDrinkingSound() { return SoundEvents.GENERIC_DRINK; }
    @Override public SoundEvent getEatingSound() { return SoundEvents.GENERIC_EAT; }
}
